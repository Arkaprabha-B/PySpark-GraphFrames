'''
Created on Jun 26, 2019
# A Simple program to show the implementation of GraphFrames using PySpark
@author: Arkaprabha_B
'''

from pyspark import SparkConf, SparkContext
from graphframes import *
from pyspark.sql import SparkSession, SQLContext

conf = SparkConf().setMaster('local').setAppName('demo3')
sc = SparkContext(conf=conf)
sqlcontext = SQLContext(sc) 

print("Initializing Spark Session")
spark = SparkSession.builder.appName('demo3').getOrCreate()

print("GraphFrames Vertices")
vertices = spark.createDataFrame([('1', 'Carter', 'Derrick', 50), 
                                  ('2', 'May', 'Derrick', 26),
                                 ('3', 'Mills', 'Jeff', 80),
                                  ('4', 'Hood', 'Robert', 65),
                                  ('5', 'Banks', 'Mike', 93),
                                 ('98', 'Berg', 'Tim', 28),
                                 ('99', 'Page', 'Allan', 16)],
                                 ['id', 'name', 'firstname', 'age'])
print("GraphFrames Edges")
edges = spark.createDataFrame([('1', '2', 'friend'), 
                               ('2', '1', 'friend'),
                              ('3', '1', 'friend'),
                              ('1', '3', 'friend'),
                               ('2', '3', 'follows'),
                               ('3', '4', 'friend'),
                               ('4', '3', 'friend'),
                               ('5', '3', 'friend'),
                               ('3', '5', 'friend'),
                               ('4', '5', 'follows'),
                              ('98', '99', 'friend'),
                              ('99', '98', 'friend')],
                              ['src', 'dst', 'type'])

print("Simple GraphFrame Program using PySpark")
g = GraphFrame(vertices, edges)

print("A Print Statement")
print(GraphFrame.vertices)

print("Yet Another Print Statement")
print(GraphFrame.edges)

print("Last But one Print Statement")
print(GraphFrame.degrees)


