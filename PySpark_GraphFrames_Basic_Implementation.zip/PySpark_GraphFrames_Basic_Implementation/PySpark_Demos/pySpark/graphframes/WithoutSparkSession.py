'''
Created on Jun 18, 2019

@author: Arkaprabha_B
'''
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, Row 
a = Row(name='ABCD', age=25, height=170) 
print("A:", a)
