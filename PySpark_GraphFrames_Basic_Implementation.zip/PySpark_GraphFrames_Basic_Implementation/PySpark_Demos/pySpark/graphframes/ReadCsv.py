'''
Created on Jun 23, 2019

@author: Arkaprabha_B
'''
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession, SQLContext

conf = SparkConf().setMaster('local').setAppName('Readcsv')
sc = SparkContext(conf=conf)
sqlcontext = SQLContext(sc) 

print("Initializing the Spark Session")
spark = SparkSession.builder.appName('Readcsv').getOrCreate()

print("Reading hello.csv file using dataframes")
df = spark.read.csv('D:\Eclipse_Workspace\Demo\graphframes\hello.csv')
df.show()
print("Printing meta data of the dataframe")
df.printSchema()

