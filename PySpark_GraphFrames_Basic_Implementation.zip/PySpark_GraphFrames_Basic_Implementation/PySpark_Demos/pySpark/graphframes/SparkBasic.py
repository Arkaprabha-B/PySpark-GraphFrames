'''
Created on Jun 24, 2019

@author: Arkaprabha_B
'''
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext

conf = SparkConf().setMaster('local').setAppName('SparkBasic')
sc = SparkContext(conf=conf)
sqlcontext = SQLContext(sc)

rdd1 = sc.parallelize([1,2,3,4])
print("Most Basic PySpark Program")
print(rdd1.collect()) 